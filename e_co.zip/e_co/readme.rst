###################
Student Information System ( A sample Web App using CodeIgniter)
###################

This is an example source code in developing a web application with CodeIgniter.

